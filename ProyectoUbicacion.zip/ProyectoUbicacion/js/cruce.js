// Función "Buscar Dirección" onclick
function buscarDireccion() {
    let calle1 = document.getElementById("calle1").value.trim();
    let calle2 = document.getElementById("calle2").value.trim();

    //latitud y longitud geolocalización
    if (esCoordenada(calle1) && esCoordenada(calle2)) {
        obtenerPorCoordenadas(calle1, calle2);
    }
    // calle y altura
    else if (esNumero(calle2)) {
        obtenerPorCalleYAltura(calle1, calle2);
    }
    // cruce entre dos calles
    else if (calle1 && calle2) {
        obtenerPorInterseccion(calle1, calle2);
    } else {
        alert("Por favor ingrese una opción válida para realizar la búsqueda.");
    }
}

// Función que determina si un valor es una coordenada válida (latitud o longitud)
function esCoordenada(valor) {
    return !isNaN(valor) && valor.indexOf('.') !== -1;
}

// Función que determina si un valor es un número (altura)
function esNumero(valor) {
    return !isNaN(valor) && valor.indexOf('.') === -1;
}

// Función que busca por intersección de calles
function obtenerPorInterseccion(calle1, calle2) {
    let url = `https://servicios.usig.buenosaires.gob.ar/normalizar/?direccion=${encodeURIComponent(calle1)}%20y%20${encodeURIComponent(calle2)}`;

    document.getElementById("resultado").innerHTML = "Buscando...";

    
    axios.get(url)
        .then(function(response) {
            console.log(response);

            // Devolución de los resultados de la API, si encuentra coincidencias
            if (response.data.direccionesNormalizadas && response.data.direccionesNormalizadas.length > 0) {
                let resultadoHTML = "";

                // Recorremos todas las direcciones encontradas
                response.data.direccionesNormalizadas.forEach(function(resultado) {
                    const detalles = `
                        <ul>
                            <li><strong>Dirección:</strong> ${resultado.direccion}</li>
                            <li><strong>Calle:</strong> ${resultado.nombre_calle}</li>
                            <li><strong>Calle de cruce:</strong> ${resultado.nombre_calle_cruce}</li>
                            <li><strong>Localidad:</strong> ${resultado.nombre_localidad}</li>
                            <li><strong>Partido:</strong> ${resultado.nombre_partido}</li>
                            <li><strong>Tipo de búsqueda:</strong> ${resultado.tipo}</li>
                        </ul>
                    `;
                    resultadoHTML += detalles;
                });

                // Mostramos las direcciones encontradas
                document.getElementById("resultado").innerHTML = `Direcciones encontradas: ${resultadoHTML}`;
            } else {
                document.getElementById("resultado").innerHTML = "No se encontraron resultados para esta intersección de calles.";
            }
        })
        .catch(function(error) {
            console.error("Error al realizar la solicitud:", error);
            document.getElementById("resultado").innerHTML = "La API no está disponible en este momento. Intenta más tarde.";
        });
}

// Función que busca por calle y altura
function obtenerPorCalleYAltura(calle, altura) {
    let url = `https://servicios.usig.buenosaires.gob.ar/normalizar/?direccion=${encodeURIComponent(calle)}%20${encodeURIComponent(altura)}`;

    document.getElementById("resultado").innerHTML = "Buscando...";

    axios.get(url)
        .then(function(response) {
            console.log(response);

            if (response.data.direccionesNormalizadas && response.data.direccionesNormalizadas.length > 0) {
                let resultadoHTML = "";

                // Recorremos todas las direcciones encontradas
                response.data.direccionesNormalizadas.forEach(function(resultado) {
                    const detalles = `
                        <ul>
                            <li><strong>Dirección:</strong> ${resultado.direccion}</li>
                            <li><strong>Calle:</strong> ${resultado.nombre_calle}</li>
                            <li><strong>Calle de cruce:</strong> ${resultado.nombre_calle_cruce}</li>
                            <li><strong>Localidad:</strong> ${resultado.nombre_localidad}</li>
                            <li><strong>Partido:</strong> ${resultado.nombre_partido}</li>
                            <li><strong>Tipo de búsqueda:</strong> ${resultado.tipo}</li>
                        </ul>
                    `;
                    resultadoHTML += detalles;
                });

                // Mostramos las direcciones encontradas
                document.getElementById("resultado").innerHTML = `Direcciones encontradas: ${resultadoHTML}`;
            } else {
                document.getElementById("resultado").innerHTML = "No se encontraron resultados para esta calle y altura.";
            }
        })
        .catch(function(error) {
            console.error("Error al realizar la solicitud:", error);
            document.getElementById("resultado").innerHTML = "La API no está disponible en este momento. Intenta más tarde.";
        });
}

// Función que busca por latitud y longitud
function obtenerPorCoordenadas(latitud, longitud) {
    
    let url = `https://servicios.usig.buenosaires.gob.ar/normalizar/?lng=${longitud}&lat=${latitud}`;

    // Mostrar mensaje de búsqueda
    document.getElementById("resultado").innerHTML = "Buscando...";

    
    axios.get(url)
        .then(function(response) {
            // Verificar si hay error en la respuesta
            if (response.data.error) {
                document.getElementById("resultado").innerHTML = "No se encontró ninguna dirección para estas coordenadas.";
            } else {
                // Extraer los datos del JSON
                const direccion = response.data.direccion || "Dirección no disponible";
                const altura = response.data.altura || "No disponible";
                const nombreCalle = response.data.nombre_calle || "No disponible";
                const nombreCalleCruce = response.data.nombre_calle_cruce || "No disponible";
                const nombreLocalidad = response.data.nombre_localidad || "No disponible";
                const nombrePartido = response.data.nombre_partido || "No disponible";

                // Crear el mensaje de salida con la información obtenida
                const resultado = `
                    Dirección: ${direccion} <br>
                    Calle: ${nombreCalle} <br>
                    Cruce: ${nombreCalleCruce} <br>
                    Localidad: ${nombreLocalidad} <br>
                    Partido: ${nombrePartido} <br>
                    Altura: ${altura} <br>
                `;
                document.getElementById("resultado").innerHTML = resultado;
            }
        })
        .catch(function(error) {
           
            console.error("Error al realizar la solicitud:", error);
            document.getElementById("resultado").innerHTML = "La API no está disponible en este momento. Intenta más tarde.";
        });
}